package pw.micmax.sysc3303.a2;

public enum Ingredient {
	Bread, PeanutButter, Jam
}
